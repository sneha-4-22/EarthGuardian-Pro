const COLORS = {
    white: "#FFFFFF",
    black: "#222222",
    primary: "#16154E",
    secondary: "#16154E",
    grey: "#CCCCCC"
}

export default COLORS;